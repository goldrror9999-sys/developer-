<?php

// 🌐 InfinityFree MySQL Configuration

// --------------------------------------------

// 👉 Go to your InfinityFree panel → MySQL Databases section

// Copy these 4 values and paste below:

$host = "sql300.infinityfree.com";   // Example: sql301.infinityfree.com

$user = "if0_40084652";              // Example: epiz_12345678

$pass = "MPDBmysql";       // Example: Your InfinityFree MySQL password

$db   = "if0_40084652_db";       // Example: epiz_12345678_mydb

// --------------------------------------------

// 🧠 Connect to MySQL

$conn = mysqli_connect($host, $user, $pass, $db);

// ❌ Error Handling

if (!$conn) {

    die("❌ Database Connection Failed: " . mysqli_connect_error());

}

// ✅ Success (Optional - remove in production)

// echo "✅ Connected to InfinityFree Database Successfully!";

?>