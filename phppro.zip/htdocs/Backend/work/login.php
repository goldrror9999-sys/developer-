<?php

include '../data/config.php';

session_start();

$message = "";

if (isset($_POST['login'])) {

    $email = $_POST['email'];

    $pass  = $_POST['password'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND password='$pass'");

    if (mysqli_num_rows($result) == 1) {

        $_SESSION['email'] = $email;

        header("Location: ../../index.php");

        exit;

    } else {

        $message = "❌ Invalid Email or Password!";

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Login</title>

  <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="flex items-center justify-center min-h-screen bg-blue-600 p-4">

  <div class="w-full max-w-4xl bg-white rounded-2xl shadow-2xl grid grid-cols-1 md:grid-cols-2 overflow-hidden">

    

    <!-- Left Column: Welcome Section -->

    <div class="relative p-8 md:p-12 bg-blue-600 text-white rounded-t-2xl md:rounded-l-2xl md:rounded-tr-none">

      <!-- Decorative Spheres -->

      <div class="absolute -top-10 -right-10 w-40 h-40 rounded-full" style="background: radial-gradient(circle, #3b82f6, #2563eb);"></div>

      <div class="absolute -bottom-16 -left-12 w-32 h-32 rounded-full" style="background: radial-gradient(circle, #3b82f6, #2563eb);"></div>

      

      <div class="relative z-10">

        <h1 class="font-bold text-4xl mb-3">WELCOME</h1>

        <p class="font-semibold text-lg mb-4">YOUR HEADLINE NAME</p>

        <p class="max-w-sm text-sm text-blue-100">

          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

        </p>

      </div>

    </div>

    <!-- Right Column: Login Form -->

    <div class="p-8 md:p-14">

      <h2 class="font-bold text-3xl text-gray-800">login in</h2>

      <p class="text-gray-500 mt-2 mb-6 text-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

      

      <?php if ($message) echo "<p class='text-center mb-4 text-sm font-medium text-red-500'>$message</p>"; ?>

      <form method="POST" class="space-y-4">

        <!-- Input Email -->

        <div class="relative">

          <span class="absolute inset-y-0 left-0 flex items-center pl-3">

            <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">

              <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />

            </svg>

          </span>

          <input 

            type="email" 

            name="email" 

            placeholder="User Gmail" 

            required 

            class="w-full pl-10 pr-4 py-3 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"

          >

        </div>

        <!-- Input Password -->

        <div class="relative">

          <span class="absolute inset-y-0 left-0 flex items-center pl-3">

            <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">

              <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />

              <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd" />

            </svg>

          </span>

          <input 

            type="password" 

            name="password" 

            placeholder="Password" 

            required 

            class="w-full pl-10 pr-4 py-3 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"

          >

          <!-- Show/Hide functionality can be added here with JavaScript -->

          <span class="absolute inset-y-0 right-0 flex items-center pr-3 text-sm font-semibold text-gray-600 cursor-pointer">SHOW</span>

        </div>

        <div class="flex justify-between items-center text-sm">

          <div class="flex items-center space-x-2">

            <input type="checkbox" id="remember" name="remember" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">

            <label for="remember" class="text-gray-600">Remember me</label>

          </div>

          <a href="#" class="font-semibold text-blue-600 hover:underline">Forgot Password?</a>

        </div>

        <button 

          type="submit" 

          name="login" 

          class="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-300 shadow-md hover:shadow-lg"

        >

          login in

        </button>

        <div class="flex items-center py-2">

          <hr class="w-full border-gray-300">

          <span class="px-2 text-sm text-gray-500">OR</span>

          <hr class="w-full border-gray-300">

        </div>

        <a 

          href="signup.php" 

          class="w-full block text-center border border-gray-300 text-gray-800 py-3 rounded-lg font-semibold hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition-all duration-300"

        >

          Sign in with other

        </a>

        

        <p class="text-center mt-6 text-sm">

          Don’t have an account? 

          <a href="signup.php" class="font-semibold text-blue-600 hover:underline">Sign Up</a>

        </p>

      </form>

    </div>

  </div>

</body>

</html>