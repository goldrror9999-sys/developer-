<?php

// 1. Session ko start karein

session_start();

// 2. Session mein store kiye gaye sabhi variables ko unset/khali karein

$_SESSION = array();

// 3. Session ko poori tarah se destroy karein

session_destroy();

// 4. User ko logout karne ke baad login.php page par bhej dein

header("Location: login.php");

// 5. নিশ্চিত karein ki redirect ke baad aage koi code execute na ho

exit;

?>