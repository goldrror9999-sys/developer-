<?php

include '../data/config.php';

$message = "";

if (isset($_POST['signup'])) {

    $name  = mysqli_real_escape_string($conn, $_POST['name']);

    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $pass  = mysqli_real_escape_string($conn, $_POST['password']);

    

    // Passwords ko hamesha hash karna chahiye

    // $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if (mysqli_num_rows($check) > 0) {

        $message = "⚠️ Email already registered!";

    } else {

        // Yahan $pass ki jagah $hashed_pass ka istemal karein

        $query = "INSERT INTO users (name, email, password) VALUES ('$name','$email','$pass')";

        if (mysqli_query($conn, $query)) {

            $message = "✅ Signup Successful! <a href='login.php' class='font-semibold text-green-600 hover:underline'>Login Now</a>";

        } else {

            $message = "❌ Error: " . mysqli_error($conn);

        }

    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Create an Account</title>

  <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="flex items-center justify-center min-h-screen bg-green-600 p-4">

  <div class="w-full max-w-4xl bg-white rounded-2xl shadow-2xl grid grid-cols-1 md:grid-cols-2 overflow-hidden">

    

    <!-- Left Column: Welcome Section -->

    <div class="relative p-8 md:p-12 bg-green-600 text-white rounded-t-2xl md:rounded-l-2xl md:rounded-tr-none">

      <!-- Decorative Spheres -->

      <div class="absolute -top-12 -right-12 w-40 h-40 rounded-full" style="background: radial-gradient(circle, #4ade80, #16a34a);"></div>

      <div class="absolute -bottom-16 -left-12 w-32 h-32 rounded-full" style="background: radial-gradient(circle, #4ade80, #16a34a);"></div>

      

      <div class="relative z-10">

        <h1 class="font-bold text-4xl mb-3">Get Started</h1>

        <p class="font-semibold text-lg mb-4">A NEW JOURNEY BEGINS</p>

        <p class="max-w-sm text-sm text-green-100">

          Create an account to continue and explore all the features available for you.

        </p>

      </div>

    </div>

    <!-- Right Column: Signup Form -->

    <div class="p-8 md:p-14">

      <h2 class="font-bold text-3xl text-gray-800">Create Account</h2>

      <p class="text-gray-500 mt-2 mb-6 text-sm">Join us by creating your account below.</p>

      

      <?php 

        // HTML entities ko encode karein taaki message mein HTML aane par UI break na ho

        if ($message) {

            // PHP 8+ ke liye htmlspecialchars_decode() ka use karke allow karein, taki link kaam kare.

            // Lekin behtar practice yeh hai ki link ko alag se handle karein.

            $isSuccess = strpos($message, "✅") !== false;

            $messageClass = $isSuccess ? 'text-green-600' : 'text-red-500';

            echo "<div class='text-center mb-4 text-sm font-medium p-3 rounded-lg " . ($isSuccess ? 'bg-green-50' : 'bg-red-50') . " $messageClass'>$message</div>";

        }

      ?>

      <form method="POST" class="space-y-4">

        <!-- Input Full Name -->

        <div class="relative">

          <span class="absolute inset-y-0 left-0 flex items-center pl-3">

            <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">

              <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />

            </svg>

          </span>

          <input 

            type="text" 

            name="name" 

            placeholder="Full Name" 

            required 

            class="w-full pl-10 pr-4 py-3 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500 transition-all duration-300"

          >

        </div>

        <!-- Input Email -->

        <div class="relative">

          <span class="absolute inset-y-0 left-0 flex items-center pl-3">

            <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">

                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />

                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />

            </svg>

          </span>

          <input 

            type="email" 

            name="email" 

            placeholder="Email Address" 

            required 

            class="w-full pl-10 pr-4 py-3 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500 transition-all duration-300"

          >

        </div>

        <!-- Input Password -->

        <div class="relative">

          <span class="absolute inset-y-0 left-0 flex items-center pl-3">

            <svg class="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">

              <path fill-rule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v2H2v-4l4.257-4.257A6 6 0 0118 8zm-6-4a1 1 0 100 2 2 2 0 01-2 2 1 1 0 100 2 4 4 0 004-4 1 1 0 00-2 0z" clip-rule="evenodd" />

            </svg>

          </span>

          <input 

            type="password" 

            name="password" 

            placeholder="Password" 

            required 

            class="w-full pl-10 pr-4 py-3 border rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-green-500 transition-all duration-300"

          >

        </div>

        <button 

          type="submit" 

          name="signup" 

          class="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-all duration-300 shadow-md hover:shadow-lg"

        >

          Sign Up

        </button>

        

        <p class="text-center pt-4 text-sm">

          Already have an account? 

          <a href="login.php" class="font-semibold text-green-600 hover:underline">Login</a>

        </p>

      </form>

    </div>

  </div>

</body>

</html>