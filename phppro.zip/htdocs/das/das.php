<?php

// das.php

// error_reporting(0); // Uncomment for production to hide warnings

require_once 'ds_config.php';

// Admin credentials

$ADMIN_USER = 'developer';

$ADMIN_PASS = 'python@929';

// Logout action

if (isset($_GET['action']) && $_GET['action'] === 'logout') {

    if (session_status() == PHP_SESSION_ACTIVE) {

        session_destroy();

    }

    header("Location: das.php");

    exit;

}

// Handle login post

$login_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {

    $u = isset($_POST['username']) ? trim($_POST['username']) : '';

    $p = isset($_POST['password']) ? $_POST['password'] : '';

    if ($u === $ADMIN_USER && $p === $ADMIN_PASS) {

        $_SESSION['admin_logged_in'] = true;

        $_SESSION['admin_user'] = $ADMIN_USER;

        header("Location: das.php");

        exit;

    } else {

        $login_error = "Invalid credentials. Please try again.";

    }

}

// Check if logged in

$logged = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

?>

<!doctype html>

<html lang="en">

<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width,initial-scale=1">

  <title>Dashboard — Developer ji</title>

  <script src="https://cdn.tailwindcss.com"></script>

  <style>

    /* Custom glassmorphism and hover effects */

    .glass-card {

      background: rgba(255, 255, 255, 0.05);

      backdrop-filter: blur(10px);

      border: 1px solid rgba(255, 255, 255, 0.1);

      transition: transform 0.3s ease, box-shadow 0.3s ease;

    }

    .glass-card:hover {

      transform: translateY(-8px);

      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);

    }

  </style>

</head>

<body class="bg-slate-900 text-white min-h-screen flex items-center justify-center p-4 sm:p-6">

  <div class="w-full max-w-7xl mx-auto">

    <?php if (!$logged): ?>

      <!-- Login / Landing Page -->

      <div class="grid gap-8 md:grid-cols-2 items-center max-w-4xl mx-auto">

        

        <!-- Login Form Column -->

        <div class="relative bg-white text-slate-800 p-8 rounded-2xl shadow-2xl overflow-hidden">

          <!-- Decorative Spheres -->

          <div class="absolute -top-16 -left-16 w-48 h-48 bg-gradient-to-br from-blue-500 to-green-400 rounded-full opacity-30"></div>

          <div class="absolute -bottom-12 -right-12 w-32 h-32 bg-gradient-to-br from-green-400 to-teal-300 rounded-full opacity-30"></div>

          

          <div class="relative z-10">

            <h1 class="text-3xl font-bold mb-2 text-slate-900">Admin Access</h1>

            <p class="text-gray-600 mb-6">Login to access the secure dashboard.</p>

            

            <?php if ($login_error): ?>

              <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-3 rounded-md mb-4 text-sm"><?php echo htmlspecialchars($login_error); ?></div>

            <?php endif; ?>

            

            <form method="post" class="space-y-4">

              <input name="username" placeholder="Username" required class="w-full p-3 rounded-lg border bg-gray-50 border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition">

              <input name="password" type="password" placeholder="Password" required class="w-full p-3 rounded-lg border bg-gray-50 border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition">

              <button name="login" type="submit" class="w-full py-3 rounded-lg bg-gradient-to-r from-blue-600 to-green-500 text-white font-bold hover:from-blue-700 hover:to-green-600 transition-all duration-300 transform hover:scale-105 shadow-lg">Login</button>

            </form>

            <p class="text-xs text-gray-400 mt-4 text-center">Hint: Use credentials provided by Developer ji.</p>

          </div>

        </div>

        <!-- Welcome/Preview Column (Hidden on mobile) -->

        <div class="hidden md:block p-8 rounded-2xl glass-card">

          <h2 class="text-2xl font-semibold mb-3">Welcome to Dashboard</h2>

          <p class="opacity-80">A professional UI with responsive design and quick access to your data tables.</p>

          <div class="mt-6 grid grid-cols-2 gap-4">

            <?php for ($i=1;$i<=6;$i++): ?>

              <div class="rounded-lg p-4 bg-white/10 transition hover:bg-white/20">

                <div class="text-sm opacity-80">Widget <?php echo $i; ?></div>

                <div class="text-xl font-bold mt-2">—</div>

              </div>

            <?php endfor; ?>

          </div>

        </div>

      </div>

    <?php else: ?>

      <!-- Dashboard Content -->

      <div>

        <div class="mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">

          <div>

            <h1 class="text-3xl font-bold">Welcome, <?php echo htmlspecialchars($_SESSION['admin_user']); ?> 👋</h1>

            <p class="text-sm text-slate-400">Secure Dashboard Center — Modern UI.</p>

          </div>

          <a href="das.php?action=logout" class="px-4 py-2 bg-red-600/20 text-red-300 border border-red-500/30 rounded-lg hover:bg-red-500 hover:text-white transition-colors duration-300 text-sm font-semibold">Logout</a>

        </div>

        

        <?php

        $tables = [];

        if (isset($mysqli)) {

          $r = $mysqli->query("SHOW TABLES");

          if ($r) {

            while ($row = $r->fetch_array()) $tables[] = $row[0];

            $r->free();

          }

        }

        

        $userCount = 0;

        $foundTable = 'users'; // default

        if (isset($mysqli) && in_array('users', $tables)) {

          $q = $mysqli->query("SELECT COUNT(*) AS c FROM `users`");

          if ($q) { $tmp = $q->fetch_assoc(); $userCount = (int)$tmp['c']; $q->free(); }

        }

        

        $cards = [

          ['title'=>'Users', 'desc'=>"Total: $userCount", 'link'=>'user_tb.php?table='.$foundTable, 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>'],

          ['title'=>'Analytics', 'desc'=>'View Stats', 'link'=>'#', 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>'],

          ['title'=>'Settings', 'desc'=>'System Config', 'link'=>'#', 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>'],

        ];

        ?>

        <div class="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">

          <?php foreach ($cards as $c): ?>

            <a href="<?php echo $c['link']; ?>" class="block p-6 rounded-2xl glass-card group">

              <div class="flex items-center justify-between">

                <div class="text-4xl text-green-400 group-hover:text-blue-400 transition-colors duration-300"><?php echo $c['icon']; ?></div>

              </div>

              <div class="mt-4">

                <div class="text-xl font-semibold"><?php echo htmlspecialchars($c['title']); ?></div>

                <div class="text-sm text-slate-400 mt-1"><?php echo htmlspecialchars($c['desc']); ?></div>

              </div>

            </a>

          <?php endforeach; ?>

        </div>

        

        <div class="mt-8 bg-slate-800/50 border border-slate-700 p-6 rounded-2xl">

          <h2 class="font-semibold mb-4 text-xl">Database Tables</h2>

          <?php if (empty($tables)): ?>

            <p class="text-slate-400">No tables found in the database or database connection failed.</p>

          <?php else: ?>

            <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3">

              <?php foreach ($tables as $t): 

                  $safe = htmlspecialchars($t);

                  $cnt = '?';

                  if (isset($mysqli)) {

                      $r2 = $mysqli->query("SELECT COUNT(*) AS c FROM `".$mysqli->real_escape_string($t)."`");

                      if ($r2) { $c2 = $r2->fetch_assoc(); $cnt = (int)$c2['c']; $r2->free(); }

                  }

              ?>

                <a href="user_tb.php?table=<?php echo urlencode($t); ?>" class="p-4 rounded-lg border border-slate-600 flex justify-between items-center hover:bg-slate-700 hover:border-blue-500 transition-all duration-300">

                  <div class="font-mono font-semibold"><?php echo $safe; ?></div>

                  <div class="text-sm text-slate-400"><?php echo $cnt; ?> rows</div>

                </a>

              <?php endforeach; ?>

            </div>

          <?php endif; ?>

        </div>

      </div>

    <?php endif; ?>

  </div>

</body>

</html>