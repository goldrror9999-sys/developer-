<?php

// delete_user.php

require_once 'ds_config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {

    echo json_encode(['success'=>false,'error'=>'Not authorized']); exit;

}

$input = json_decode(file_get_contents('php://input'), true);

$table = $input['table'] ?? '';

$id = $input['id'] ?? '';

if (!$table || !$id) { echo json_encode(['success'=>false,'error'=>'Missing']); exit; }

$tables = []; $r = $mysqli->query("SHOW TABLES");

if ($r) { while ($row = $r->fetch_array()) $tables[] = $row[0]; $r->free(); }

if (!in_array($table, $tables)) { echo json_encode(['success'=>false,'error'=>'Invalid table']); exit; }

$stmt = $mysqli->prepare("DELETE FROM `".$mysqli->real_escape_string($table)."` WHERE `id` = ?");

if (!$stmt) { echo json_encode(['success'=>false,'error'=>'Prepare failed']); exit; }

$stmt->bind_param('i', $id);

$ok = $stmt->execute();

if ($ok) echo json_encode(['success'=>true]);

else echo json_encode(['success'=>false,'error'=>$stmt->error]);