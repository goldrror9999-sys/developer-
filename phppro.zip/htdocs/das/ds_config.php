<?php

// ds_config.php

// Edit karo yahan apne InfinityFree ke DB credentials

$db_host = 'sql300.infinityfree.com';   // replace with your host

$db_user = 'if0_40084652';       // replace

$db_pass = 'MPDBmysql';   // replace

$db_name = 'if0_40084652_db'; // replace

$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($mysqli->connect_errno) {

    http_response_code(500);

    echo "DB connection failed: (" . $mysqli->connect_errno . ") " . htmlspecialchars($mysqli->connect_error);

    exit;

}

$mysqli->set_charset("utf8mb4");

// Start session helper

if (session_status() === PHP_SESSION_NONE) session_start();