<?php

// update_user.php

require_once 'ds_config.php';

header('Content-Type: application/json');

// require admin

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {

    echo json_encode(['success'=>false,'error'=>'Not authorized']); exit;

}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) { echo json_encode(['success'=>false,'error'=>'Invalid input']); exit; }

$table = $input['table'] ?? '';

$id = $input['id'] ?? '';

$col = $input['col'] ?? '';

$value = $input['value'] ?? '';

// validate

if (!$table || !$id || !$col) { echo json_encode(['success'=>false,'error'=>'Missing params']); exit; }

// ensure table and column exist

$tables = []; $r = $mysqli->query("SHOW TABLES");

if ($r) { while ($row = $r->fetch_array()) $tables[] = $row[0]; $r->free(); }

if (!in_array($table, $tables)) { echo json_encode(['success'=>false,'error'=>'Invalid table']); exit; }

$cols = []; $r2 = $mysqli->query("SHOW COLUMNS FROM `".$mysqli->real_escape_string($table)."`");

if ($r2) { while ($c = $r2->fetch_assoc()) $cols[] = $c['Field']; $r2->free(); }

if (!in_array($col, $cols)) { echo json_encode(['success'=>false,'error'=>'Invalid column']); exit; }

// prepare update

$stmt = $mysqli->prepare("UPDATE `".$mysqli->real_escape_string($table)."` SET `".$mysqli->real_escape_string($col)."` = ? WHERE `id` = ?");

if (!$stmt) { echo json_encode(['success'=>false,'error'=>'Prepare failed']); exit; }

$stmt->bind_param('si', $value, $id);

$ok = $stmt->execute();

if ($ok) echo json_encode(['success'=>true]);

else echo json_encode(['success'=>false,'error'=>$stmt->error]);