<?php

// user_tb.php

require_once 'ds_config.php';

// require admin login

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {

    header("Location: das.php");

    exit;

}

// get table param

$table = isset($_GET['table']) ? $_GET['table'] : '';

if (!$table) {

    die("Table not specified. Go back to <a href='das.php'>Dashboard</a>.");

}

// validate table exists

$tables = [];

if (isset($mysqli)) {

    $res = $mysqli->query("SHOW TABLES");

    if ($res) {

        while ($r = $res->fetch_array()) $tables[] = $r[0];

        $res->free();

    }

}

if (!in_array($table, $tables)) {

    die("Invalid table. <a href='das.php'>Back</a>");

}

// get columns

$cols = [];

if (isset($mysqli)) {

    $r2 = $mysqli->query("SHOW COLUMNS FROM `".$mysqli->real_escape_string($table)."`");

    if ($r2) {

        while ($c = $r2->fetch_assoc()) $cols[] = $c['Field'];

        $r2->free();

    }

}

// pagination

$per_page = 20;

$page = isset($_GET['page']) ? max(1,(int)$_GET['page']) : 1;

$total = 0;

if (isset($mysqli)) {

    $r3 = $mysqli->query("SELECT COUNT(*) AS c FROM `".$mysqli->real_escape_string($table)."`");

    if ($r3) { $tmp = $r3->fetch_assoc(); $total = (int)$tmp['c']; $r3->free(); }

}

$orderBy = in_array('id', $cols) ? 'ORDER BY `id` DESC' : '';

$offset = ($page-1)*$per_page;

$q = "SELECT * FROM `".$mysqli->real_escape_string($table)."` $orderBy LIMIT $per_page OFFSET $offset";

$rows = [];

if (isset($mysqli)) {

    $resRows = $mysqli->query($q);

    $rows = $resRows ? $resRows->fetch_all(MYSQLI_ASSOC) : [];

}

?>

<!doctype html>

<html lang="en">

<head>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width,initial-scale=1">

  <title><?php echo htmlspecialchars($table); ?> — Table View</title>

  <script src="https://cdn.tailwindcss.com"></script>

</head>

<body class="bg-slate-900 text-white min-h-screen p-4 sm:p-6 relative overflow-x-hidden">

  

  <!-- Decorative background spheres -->

  <div class="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-blue-900 to-transparent rounded-full -translate-x-1/2 -translate-y-1/2 opacity-50 blur-3xl"></div>

  <div class="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-br from-green-900 to-transparent rounded-full translate-x-1/2 translate-y-1/2 opacity-50 blur-3xl"></div>

  <div class="max-w-7xl mx-auto relative z-10">

    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-4">

      <div>

        <h1 class="text-3xl font-bold flex items-center gap-3">

            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>

            <span><?php echo htmlspecialchars($table); ?></span>

        </h1>

        <p class="text-sm text-slate-400 mt-1">Click a cell to edit, press Enter or click outside to save.</p>

      </div>

      <div class="flex gap-3">

        <a href="das.php" class="px-4 py-2 bg-slate-700/50 text-slate-300 border border-slate-600 rounded-lg hover:bg-slate-700 transition flex items-center gap-2">

            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" /></svg>

            Back

        </a>

        <button id="refreshBtn" class="px-4 py-2 bg-gradient-to-r from-blue-600 to-green-500 text-white font-semibold rounded-lg hover:opacity-90 transition transform hover:scale-105 flex items-center gap-2">

            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h5M20 20v-5h-5M4 4l5 5M20 20l-5-5" /></svg>

            Refresh

        </button>

      </div>

    </div>

    <div class="bg-slate-800/50 border border-slate-700 rounded-2xl shadow-lg overflow-x-auto">

      <table class="min-w-full text-sm">

        <thead class="bg-slate-700/50">

          <tr>

            <?php foreach ($cols as $c): ?>

              <th class="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider"><?php echo htmlspecialchars($c); ?></th>

            <?php endforeach; ?>

            <th class="px-4 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">Actions</th>

          </tr>

        </thead>

        <tbody class="divide-y divide-slate-700">

          <?php if (count($rows) === 0): ?>

            <tr><td class="p-6 text-slate-400" colspan="<?php echo count($cols)+1; ?>">No rows found in this table.</td></tr>

          <?php else: ?>

            <?php foreach ($rows as $r): ?>

              <tr class="hover:bg-slate-700/50 transition-colors duration-200">

                <?php foreach ($cols as $c): 

                  $val = isset($r[$c]) ? $r[$c] : '';

                  $isPassword = (stripos($c,'pass') !== false);

                  $display = $isPassword ? str_repeat('•', 8) : htmlspecialchars($val);

                  $isEditable = !$isPassword && isset($r['id']);

                ?>

                  <td class="px-4 py-3 align-top whitespace-nowrap">

                    <div <?php echo $isEditable ? 'contenteditable="true"' : ''; ?>

                         data-col="<?php echo htmlspecialchars($c); ?>"

                         data-id="<?php echo htmlspecialchars($r['id'] ?? ''); ?>"

                         class="<?php echo $isEditable ? 'editable rounded-md outline-none focus:bg-slate-600 focus:ring-2 focus:ring-blue-500 px-2 -mx-2 py-1 -my-1' : ''; ?>"

                         ><?php echo $display; ?></div>

                  </td>

                <?php endforeach; ?>

                <td class="px-4 py-3 whitespace-nowrap">

                  <?php if(isset($r['id'])): ?>

                  <button class="deleteBtn px-3 py-1 text-xs bg-red-500/10 text-red-400 rounded-full hover:bg-red-500 hover:text-white transition flex items-center gap-1" data-id="<?php echo htmlspecialchars($r['id']); ?>">

                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" /></svg>

                    Delete

                  </button>

                  <?php endif; ?>

                </td>

              </tr>

            <?php endforeach; ?>

          <?php endif; ?>

        </tbody>

      </table>

    </div>

    <!-- pagination -->

    <?php $pages = max(1, (int)ceil($total / $per_page)); ?>

    <div class="mt-6 flex flex-col sm:flex-row items-center justify-between text-sm text-slate-400 gap-4">

      <div>Showing page <span class="font-bold text-white"><?php echo $page; ?></span> of <span class="font-bold text-white"><?php echo $pages; ?></span> — Total <span class="font-bold text-white"><?php echo $total; ?></span> rows</div>

      <div class="flex gap-2">

        <?php if ($page > 1): ?>

          <a href="?table=<?php echo urlencode($table); ?>&page=<?php echo $page-1; ?>" class="px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md hover:bg-slate-700 transition">Prev</a>

        <?php endif; ?>

        <?php if ($page < $pages): ?>

          <a href="?table=<?php echo urlencode($table); ?>&page=<?php echo $page+1; ?>" class="px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-md hover:bg-slate-700 transition">Next</a>

        <?php endif; ?>

      </div>

    </div>

  </div>

<script>

document.getElementById('refreshBtn').addEventListener('click', () => location.reload());

// inline save on blur or Enter

document.querySelectorAll('.editable').forEach(el => {

  el.addEventListener('keydown', function(e) {

    if (e.key === 'Enter') {

      e.preventDefault();

      this.blur();

    }

  });

  el.addEventListener('blur', function() {

    const id = this.dataset.id;

    const col = this.dataset.col;

    let value = this.innerText.trim();

    

    fetch('update_user.php', {

      method: 'POST',

      headers: {'Content-Type':'application/json'},

      body: JSON.stringify({table: "<?php echo addslashes($table); ?>", id: id, col: col, value: value})

    }).then(r => r.json()).then(res => {

      if (!res.success) {

        alert('Update failed: ' + (res.error || 'unknown error'));

      }

    }).catch(err => {

      console.error('Fetch Error:', err);

      alert('An error occurred while sending the request.');

    });

  });

});

// delete

document.querySelectorAll('.deleteBtn').forEach(btn => {

  btn.addEventListener('click', function() {

    const id = this.dataset.id;

    if (!confirm('Are you sure you want to delete row with id = ' + id + '?')) return;

    

    fetch('delete_user.php', {

      method:'POST',

      headers: {'Content-Type':'application/json'},

      body: JSON.stringify({table: "<?php echo addslashes($table); ?>", id: id})

    }).then(r => r.json()).then(res => {

      if (res.success) {

        location.reload();

      } else {

        alert('Delete failed: ' + (res.error || 'unknown error'));

      }

    }).catch(() => alert('An error occurred while sending the request.'));

  });

});

</script>

</body>

</html>