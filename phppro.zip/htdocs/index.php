<?php

// PHP session check at the top

 session_start();

if (!isset($_SESSION['email'])) {

    header("Location: Backend/work/login.php");
 
    exit;
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Home | Development</title>

  

  <!-- Tailwind CSS CDN -->

  <script src="https://cdn.tailwindcss.com"></script>

  

  <!-- AOS.js (Animate On Scroll) Library for animations -->

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

  

  <style>

    /* Custom style for a more premium background and typing cursor */

    body {

      background-color: #111827; /* bg-gray-900 */

      background-image: radial-gradient(circle at top, rgba(31, 41, 55, 0.8), #111827);

    }

    .typing-cursor::after {

      content: '|';

      animation: blink 1s step-end infinite;

    }

    @keyframes blink {

      from, to { color: transparent }

      50% { color: #4ade80; } /* Green cursor */

    }

    .card-glow:hover {

        box-shadow: 0 0 25px rgba(59, 130, 246, 0.3); /* Blue glow on hover */

    }

  </style>

</head>

<body class="text-white font-sans">

  <!-- =================================================================

       HEADER SECTION

  ================================================================== -->

  <header class="bg-gradient-to-r from-green-500 via-blue-600 to-transparent sticky top-0 z-50 shadow-lg">

    <nav class="container mx-auto px-6 py-3 flex justify-between items-center">

      <a href="#" class="flex items-center gap-2 text-xl font-bold">

        <!-- New Code Icon -->

        <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">

          <path stroke-linecap="round" stroke-linejoin="round" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />

        </svg>

        <span>Development</span>

      </a>

      

      <!-- User Icon and Dropdown -->

      <div class="relative">

        <button id="userMenuButton" class="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-white">

          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>

        </button>

        

        <div id="userDropdown" class="hidden absolute right-0 mt-2 w-48 bg-white text-slate-800 rounded-md shadow-xl py-1">

          <a href="profile.php" class="block px-4 py-2 text-sm hover:bg-slate-100">Profile</a>

          <button id="aboutButton" class="w-full text-left block px-4 py-2 text-sm hover:bg-slate-100">About</button>

          <a href="/Backend/work/loginout.php" class="block px-4 py-2 text-sm hover:bg-slate-100 red-600">Logout</a>

        </div>

      </div>

    </nav>

  </header>

  <!-- =================================================================

       MAIN / HERO SECTION

  ================================================================== -->

  <main class="min-h-screen flex flex-col items-center justify-center text-center px-6 -mt-16">

    <div data-aos="fade-up">

      <h1 class="text-5xl md:text-7xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-500">

        Welcome

      </h1>

    </div>

    <div data-aos="fade-up" data-aos-delay="200">

      <h2 id="changingHeading" class="text-2xl md:text-4xl font-semibold mt-4 h-12 md:h-14 typing-cursor"></h2>

    </div>

    <div data-aos="fade-up" data-aos-delay="400">

        <p class="text-slate-300 mt-4 max-w-xl">

            This is a modern and dynamic user interface built with the power of PHP and Tailwind CSS, designed to provide a seamless user experience.

        </p>

    </div>

    <div data-aos="fade-up" data-aos-delay="600">

      <a href="#features" class="mt-8 inline-block px-8 py-3 bg-gradient-to-r from-green-500 to-blue-600 rounded-full font-bold text-lg hover:from-green-600 hover:to-blue-700 transition-all duration-300 transform hover:scale-110 shadow-lg">

        Get Started

      </a>

    </div>

  </main>

  <!-- =================================================================

       FEATURES / CARDS SECTION

  ================================================================== -->

  <section id="features" class="py-20 px-6 container mx-auto">

    <h2 class="text-3xl font-bold text-center mb-12" data-aos="fade-up">Explore Features</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">

      

      <!-- Card 1: Analytics -->

      <a href="feature1.php" class="block bg-gray-800 rounded-2xl p-6 transform hover:-translate-y-2 transition-all duration-300 card-glow border border-transparent hover:border-blue-500" data-aos="fade-up">

        <div class="w-16 h-16 mb-4 bg-green-500/10 rounded-lg flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg></div>

        <h3 class="font-bold text-xl mb-2">Analytics Dashboard</h3>

        <p class="text-slate-400 text-sm">View detailed analytics and track your performance.</p>

      </a>

      

      <!-- Card 2: User Management -->

      <a href="feature2.php" class="block bg-gray-800 rounded-2xl p-6 transform hover:-translate-y-2 transition-all duration-300 card-glow border border-transparent hover:border-blue-500" data-aos="fade-up" data-aos-delay="100">

        <div class="w-16 h-16 mb-4 bg-blue-500/10 rounded-lg flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21a6 6 0 00-9-5.197M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg></div>

        <h3 class="font-bold text-xl mb-2">User Management</h3>

        <p class="text-slate-400 text-sm">Easily manage all users from a centralized panel.</p>

      </a>

      <!-- Card 3: Cloud Storage -->

      <a href="feature3.php" class="block bg-gray-800 rounded-2xl p-6 transform hover:-translate-y-2 transition-all duration-300 card-glow border border-transparent hover:border-blue-500" data-aos="fade-up" data-aos-delay="200">

        <div class="w-16 h-16 mb-4 bg-indigo-500/10 rounded-lg flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" /></svg></div>

        <h3 class="font-bold text-xl mb-2">Cloud Storage</h3>

        <p class="text-slate-400 text-sm">Securely store and access your files from anywhere.</p>

      </a>

      

      <!-- Card 4: Settings -->

      <a href="feature4.php" class="block bg-gray-800 rounded-2xl p-6 transform hover:-translate-y-2 transition-all duration-300 card-glow border border-transparent hover:border-blue-500" data-aos="fade-up" data-aos-delay="300">

        <div class="w-16 h-16 mb-4 bg-purple-500/10 rounded-lg flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg></div>

        <h3 class="font-bold text-xl mb-2">Advanced Settings</h3>

        <p class="text-slate-400 text-sm">Customize the application to fit your needs.</p>

      </a>

      <!-- Card 5: Support -->

      <a href="feature5.php" class="block bg-gray-800 rounded-2xl p-6 transform hover:-translate-y-2 transition-all duration-300 card-glow border border-transparent hover:border-blue-500" data-aos="fade-up" data-aos-delay="400">

        <div class="w-16 h-16 mb-4 bg-pink-500/10 rounded-lg flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-pink-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z" /></svg></div>

        <h3 class="font-bold text-xl mb-2">24/7 Support</h3>

        <p class="text-slate-400 text-sm">Get help from our dedicated support team anytime.</p>

      </a>

      <!-- Card 6: API -->

      <a href="feature6.php" class="block bg-gray-800 rounded-2xl p-6 transform hover:-translate-y-2 transition-all duration-300 card-glow border border-transparent hover:border-blue-500" data-aos="fade-up" data-aos-delay="500">

        <div class="w-16 h-16 mb-4 bg-amber-500/10 rounded-lg flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" /></svg></div>

        <h3 class="font-bold text-xl mb-2">API Integration</h3>

        <p class="text-slate-400 text-sm">Connect your favorite tools with our powerful API.</p>

      </a>

    </div>

  </section>

  

  <!-- =================================================================

       FOOTER SECTION

  ================================================================== -->

  <footer class="border-t border-slate-700 mt-12 py-8">

    <div class="container mx-auto text-center text-slate-400">

      <div class="flex justify-center gap-6 mb-4">

        <!-- Social Icons... (same as before) -->

  <a href="#" class="hover:text-white transition"><svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.252-.148-4.771-1.691-4.919-4.919-.058-1.265-.069-1.645-.069-4.85s.011-3.584.069-4.85c.149-3.225 1.664-4.771 4.919-4.919C8.416 2.175 8.796 2.163 12 2.163m0-1.623C8.724.54 8.323.552 7.078.61c-3.484.158-5.937 2.613-6.095 6.095C.552 8.323.54 8.724.54 12s.012 3.677.07 4.922c.158 3.484 2.613 5.937 6.095 6.095 1.245.058 1.646.07 4.922.07s3.677-.012 4.922-.07c3.484-.158 5.937-2.613 6.095-6.095.058-1.245.07-1.646.07-4.922s-.012-3.677-.07-4.922c-.158-3.484-2.613-5.937-6.095-6.095C15.677.552 15.276.54 12 .54z"></path><path d="M12 6.865a5.135 5.135 0 100 10.27 5.135 5.135 0 000-10.27zm0 8.644a3.509 3.509 0 110-7.018 3.509 3.509 0 010 7.018zM16.949 5.235a1.232 1.232 0 100 2.464 1.232 1.232 0 000-2.464z"></path></svg></a>
        <a href="#" class="hover:text-white transition"><svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"></path></svg></a>
        <a href="#" class="hover:text-white transition"><svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.225 0z"></p></svg></a>
      </div>
      <p>&copy; <?php echo date("Y"); ?> Development. All Rights Reserved.</p>

    </div>

  </footer>

  

  <!-- =================================================================

       ABOUT MODAL POPUP

  ================================================================== -->

  <div id="aboutModal" class="hidden fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-6">

    <div class="bg-slate-800 rounded-2xl shadow-xl p-8 max-w-lg w-full transform transition-all" data-aos="zoom-in">

      <div class="flex justify-between items-center mb-4">

        <h2 class="text-2xl font-bold">About Development</h2>

        <button id="closeModalButton" class="text-slate-400 hover:text-white text-3xl">&times;</button>

      </div>

      <p class="text-slate-300">

        This is a dynamically generated web application designed to showcase modern UI/UX principles. It integrates a PHP backend with a frontend built on Tailwind CSS and is enhanced with JavaScript for interactive animations.

      </p>

    </div>

  </div>

  <!-- AOS.js Script -->

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  

  <script>

    // Initialize AOS library

    AOS.init({

        duration: 800,

        once: true,

    });

    // --- JAVASCRIPT FOR DYNAMIC FUNCTIONALITY --- (Same as before)

    const userMenuButton = document.getElementById('userMenuButton');

    const userDropdown = document.getElementById('userDropdown');

    userMenuButton.addEventListener('click', () => userDropdown.classList.toggle('hidden'));

    window.addEventListener('click', e => { if (!userMenuButton.contains(e.target)) userDropdown.classList.add('hidden'); });

    const aboutButton = document.getElementById('aboutButton');

    const closeModalButton = document.getElementById('closeModalButton');

    const aboutModal = document.getElementById('aboutModal');

    aboutButton.addEventListener('click', () => aboutModal.classList.remove('hidden'));

    closeModalButton.addEventListener('click', () => aboutModal.classList.add('hidden'));

    aboutModal.addEventListener('click', e => { if(e.target === aboutModal) aboutModal.classList.add('hidden'); });

    const headingEl = document.getElementById('changingHeading');

    const phrases = [
 "Hello Developer",
 "Full-Stack Creator",
 "Website Builder",
 "Creative Coder",
 "Tech Enthusiast",
"Python Lover",
 "JavaScript Ninja",
 "Design Thinker",
"UI/UX Explorer",
"Code is Poetry"];

    let phraseIndex = 0, charIndex = 0;

    function type() { if (charIndex < phrases[phraseIndex].length) { headingEl.textContent += phrases[phraseIndex].charAt(charIndex++); setTimeout(type, 100); } else { setTimeout(erase, 2000); } }

    function erase() { if (charIndex > 0) { headingEl.textContent = phrases[phraseIndex].substring(0, --charIndex); setTimeout(erase, 50); } else { phraseIndex = (phraseIndex + 1) % phrases.length; setTimeout(type, 500); } }

    document.addEventListener('DOMContentLoaded', type);

  </script>

</body>

</html>